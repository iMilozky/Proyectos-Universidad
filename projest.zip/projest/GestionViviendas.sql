-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:        8.0.44-0ubuntu0.24.04.1 - (Ubuntu)
-- SO del servidor:              Linux
-- HeidiSQL Versión:            12.12.1.208
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para GestionViviandasU
CREATE DATABASE IF NOT EXISTS `GestionViviandasU` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `GestionViviandasU`;

-- Volcando estructura para tabla GestionViviandasU.cama
CREATE TABLE IF NOT EXISTS `cama` (
  `cama_id` int NOT NULL AUTO_INCREMENT,
  `etiqueta` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `habitacion_id` int NOT NULL,
  PRIMARY KEY (`cama_id`),
  KEY `habitacion_id` (`habitacion_id`),
  CONSTRAINT `cama_ibfk_1` FOREIGN KEY (`habitacion_id`) REFERENCES `habitacion` (`habitacion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.cama: ~5 rows (aproximadamente)
INSERT INTO `cama` (`cama_id`, `etiqueta`, `estado`, `habitacion_id`) VALUES
	(1, 'A-101', 'Ocupada', 1),
	(2, 'B-101', 'Disponible', 1),
	(3, 'C-102', 'Ocupada', 2),
	(4, 'D-201', 'Ocupada', 3),
	(5, 'E-301', 'Disponible', 4);

-- Volcando estructura para tabla GestionViviandasU.contrato
CREATE TABLE IF NOT EXISTS `contrato` (
  `contrato_id` int NOT NULL AUTO_INCREMENT,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `pago_mensualidad` decimal(10,2) NOT NULL,
  `deposito` decimal(10,2) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `cama_id` int NOT NULL,
  `estudiante_id` int NOT NULL,
  PRIMARY KEY (`contrato_id`),
  KEY `cama_id` (`cama_id`),
  KEY `estudiante_id` (`estudiante_id`),
  CONSTRAINT `contrato_ibfk_1` FOREIGN KEY (`cama_id`) REFERENCES `cama` (`cama_id`),
  CONSTRAINT `contrato_ibfk_2` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiante` (`estudiante_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.contrato: ~5 rows (aproximadamente)
INSERT INTO `contrato` (`contrato_id`, `fecha_inicio`, `fecha_fin`, `pago_mensualidad`, `deposito`, `estado`, `cama_id`, `estudiante_id`) VALUES
	(1, '2025-01-15', '2025-12-15', 800.00, 800.00, 'Vigente', 1, 1),
	(2, '2025-01-20', '2025-06-20', 950.00, 950.00, 'Vigente', 2, 2),
	(3, '2025-02-01', '2025-11-30', 800.00, 800.00, 'Vigente', 3, 3),
	(4, '2025-03-10', '2025-12-10', 950.00, 950.00, 'Vigente', 4, 4),
	(5, '2025-04-01', '2026-03-31', 750.00, 750.00, 'Vigente', 5, 5),
	(6, '2015-12-06', '2016-06-06', 100.00, 50.00, 'Vigente', 1, 2);

-- Volcando estructura para tabla GestionViviandasU.estudiante
CREATE TABLE IF NOT EXISTS `estudiante` (
  `estudiante_id` int NOT NULL AUTO_INCREMENT,
  `documento_ID` varchar(20) NOT NULL,
  `nombre_completo` varchar(150) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `programa` varchar(100) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`estudiante_id`),
  UNIQUE KEY `documento_ID` (`documento_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.estudiante: ~4 rows (aproximadamente)
INSERT INTO `estudiante` (`estudiante_id`, `documento_ID`, `nombre_completo`, `correo`, `telefono`, `programa`, `estado`) VALUES
	(1, '1001', 'Laura Gómez', 'laura.gomez@gmail.com', '3101111111', 'Ing. Sistemas', 'Activo'),
	(2, '1002', 'Felipe Ríos', 'felipe.rios@gmail.com', '3112222222', 'Derecho', 'Activo'),
	(3, '1003', 'Andrea Vega', 'andrea.vega@gmail.com', '3123333333', 'Medicina', 'Activo'),
	(4, '1004', 'Carlos Daza', 'carlos.daza@gmail.com', '3134444444', 'Contaduría', 'Activo'),
	(5, '1005', 'Maria Paz', 'maria.paz@gmail.com', '3145555555', 'Arquitectura', 'Activo');

-- Volcando estructura para tabla GestionViviandasU.habitacion
CREATE TABLE IF NOT EXISTS `habitacion` (
  `habitacion_id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `residencia_id` int NOT NULL,
  PRIMARY KEY (`habitacion_id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `residencia_id` (`residencia_id`),
  CONSTRAINT `habitacion_ibfk_1` FOREIGN KEY (`residencia_id`) REFERENCES `residencia` (`residencia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.habitacion: ~5 rows (aproximadamente)
INSERT INTO `habitacion` (`habitacion_id`, `codigo`, `estado`, `tipo`, `residencia_id`) VALUES
	(1, 'R1-101', 'Disponible', 'Doble', 1),
	(2, 'R1-102', 'Ocupada', 'Individual', 1),
	(3, 'R1-201', 'Ocupada', 'Doble', 1),
	(4, 'R2-301', 'Disponible', 'Individual', 2),
	(5, 'R2-302', 'Ocupada', 'Doble', 2),
	(7, 'R4-502', 'Disponible', 'doble', 3);

-- Volcando estructura para tabla GestionViviandasU.inspeccion
CREATE TABLE IF NOT EXISTS `inspeccion` (
  `id_inspeccion` int NOT NULL AUTO_INCREMENT,
  `id_habitacion` int NOT NULL,
  `puntaje` decimal(4,2) NOT NULL,
  `observaciones` text,
  `fecha_inspeccion` date NOT NULL,
  PRIMARY KEY (`id_inspeccion`),
  KEY `id_habitacion` (`id_habitacion`),
  CONSTRAINT `inspeccion_ibfk_1` FOREIGN KEY (`id_habitacion`) REFERENCES `habitacion` (`habitacion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.inspeccion: ~0 rows (aproximadamente)
INSERT INTO `inspeccion` (`id_inspeccion`, `id_habitacion`, `puntaje`, `observaciones`, `fecha_inspeccion`) VALUES
	(1, 1, 4.00, 'ninguna', '2025-07-10'),
	(2, 1, 4.80, 'Excelente estado de limpieza y orden general.', '2025-10-25'),
	(3, 2, 3.50, 'Requiere reparacion menor en el grifo del baño. Se notificó a mantenimiento.', '2025-10-26'),
	(4, 3, 5.00, 'Inspección impecable. Sin ninguna novedad, todo en perfecto estado.', '2025-10-27'),
	(5, 4, 4.10, 'Ventilación un poco deficiente. Se sugiere abrir ventanas con mayor frecuencia.', '2025-11-01'),
	(6, 5, 3.90, 'Se encontraron restos de comida. Se dejó nota de advertencia al estudiante residente.', '2025-11-02');

-- Volcando estructura para tabla GestionViviandasU.pago
CREATE TABLE IF NOT EXISTS `pago` (
  `pago_id` int NOT NULL AUTO_INCREMENT,
  `metodo_pago` varchar(50) NOT NULL,
  `fecha_pago` date NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `contrato_id` int NOT NULL,
  PRIMARY KEY (`pago_id`),
  KEY `contrato_id` (`contrato_id`),
  CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`contrato_id`) REFERENCES `contrato` (`contrato_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.pago: ~5 rows (aproximadamente)
INSERT INTO `pago` (`pago_id`, `metodo_pago`, `fecha_pago`, `monto`, `contrato_id`) VALUES
	(1, 'Transferencia', '2025-10-01', 800.00, 1),
	(2, 'Efectivo', '2025-10-05', 950.00, 2),
	(3, 'Transferencia', '2025-10-10', 800.00, 3),
	(4, 'Tarjeta', '2025-10-15', 950.00, 4),
	(5, 'Transferencia', '2025-10-20', 750.00, 5),
	(6, 'tarjeta', '2025-02-16', 800.00, 1);

-- Volcando estructura para tabla GestionViviandasU.residencia
CREATE TABLE IF NOT EXISTS `residencia` (
  `residencia_id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  PRIMARY KEY (`residencia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.residencia: ~5 rows (aproximadamente)
INSERT INTO `residencia` (`residencia_id`, `nombre`, `direccion`) VALUES
	(1, 'Residencia Central', 'Calle 5 # 10-20'),
	(2, 'Casa del Saber', 'Carrera 15 # 30-10'),
	(3, 'Torre del Campus', 'Avenida 6 # 5-55'),
	(4, 'El Hogar Universitario', 'Calle 100 # 40-A'),
	(5, 'Piso Estudiantil', 'Transversal 8 # 2-30'),
	(6, 'Edificio Central', 'calle lincon 9 ');

-- Volcando estructura para tabla GestionViviandasU.servicio
CREATE TABLE IF NOT EXISTS `servicio` (
  `id_servicio` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo_tarifa` varchar(50) NOT NULL,
  PRIMARY KEY (`id_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.servicio: ~0 rows (aproximadamente)
INSERT INTO `servicio` (`id_servicio`, `nombre`, `descripcion`, `tipo_tarifa`) VALUES
	(1, 'limpieza', 'limpieza de habitacion', 'fija'),
	(2, 'internet alta velocidad', '', 'fija'),
	(3, 'Lavanderia', 'Uso ilimitado de lavadoras y secadoras de alta eficiencia.', 'Mensual'),
	(4, 'Gimnasio', 'Acceso al gimnasio interno con equipamiento cardio y pesas.', 'Mensual'),
	(5, 'Servicio de Comidas', 'Opcion de desayuno y cena de lunes a viernes.', 'Semanal'),
	(6, 'Limpieza de Habitacion', 'Limpieza y desinfeccion profunda de la habitacion una vez por semana.', 'Mensual');

-- Volcando estructura para tabla GestionViviandasU.servicio_habitacion
CREATE TABLE IF NOT EXISTS `servicio_habitacion` (
  `id_habitacion_servicio` int NOT NULL AUTO_INCREMENT,
  `id_habitacion` int NOT NULL,
  `id_servicio` int NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date DEFAULT NULL,
  `costo_mensual` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_habitacion_servicio`),
  KEY `id_habitacion` (`id_habitacion`),
  KEY `id_servicio` (`id_servicio`),
  CONSTRAINT `servicio_habitacion_ibfk_1` FOREIGN KEY (`id_habitacion`) REFERENCES `habitacion` (`habitacion_id`),
  CONSTRAINT `servicio_habitacion_ibfk_2` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla GestionViviandasU.servicio_habitacion: ~0 rows (aproximadamente)
INSERT INTO `servicio_habitacion` (`id_habitacion_servicio`, `id_habitacion`, `id_servicio`, `fecha_inicio`, `fecha_fin`, `costo_mensual`) VALUES
	(1, 1, 2, '2025-07-15', '2025-12-16', 300000.00);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
