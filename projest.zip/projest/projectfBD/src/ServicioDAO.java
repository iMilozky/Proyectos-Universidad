import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServicioDAO {

    private static final String SELECT_ALL = "SELECT * FROM servicio";
    private static final String INSERT_SQL =
            "INSERT INTO servicio (nombre, descripcion, tipo_tarifa) VALUES (?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM servicio WHERE id_servicio = ?";
    private static final String DELETE_SQL = "DELETE FROM servicio WHERE servicio_id = ?";


    public List<Servicio> seleccionarTodos() {
        List<Servicio> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Servicio entidad = new Servicio();
                entidad.setIdServicio(resultSet.getInt("id_servicio"));
                entidad.setNombre(resultSet.getString("nombre"));
                entidad.setDescripcion(resultSet.getString("descripcion"));
                entidad.setTipoTarifa(resultSet.getString("tipo_tarifa"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer servicios: " + e.getMessage());
        }
        return entidades;
    }

    public boolean insertarServicio(Servicio servicio) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, servicio.getNombre());
            preparedStatement.setString(2, servicio.getDescripcion());
            preparedStatement.setString(3, servicio.getTipoTarifa());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar servicio: " + e.getMessage());
            return false;
        }
    }

    public Servicio seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Servicio entidad = new Servicio();
                    entidad.setIdServicio(resultSet.getInt("id_servicio"));
                    entidad.setNombre(resultSet.getString("nombre"));
                    entidad.setDescripcion(resultSet.getString("descripcion"));
                    entidad.setTipoTarifa(resultSet.getString("tipo_tarifa"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar servicio por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarServicio(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar servicio (puede tener ServicioHabitacion asociados): " + e.getMessage());
            return false;
        }
    }
}