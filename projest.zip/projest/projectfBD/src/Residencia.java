public class Residencia {

    private int residenciaId;
    private String nombre;
    private String direccion;

    public Residencia() {
    }

    public Residencia(int residenciaId, String nombre, String direccion) {
        this.residenciaId = residenciaId;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    // Getters
    public int getResidenciaId() {
        return residenciaId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    // Setters
    public void setResidenciaId(int residenciaId) {
        this.residenciaId = residenciaId;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}