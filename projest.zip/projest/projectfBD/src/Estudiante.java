public class Estudiante {

    private int estudianteId;
    private String documentoId;
    private String nombreCompleto;
    private String correo;
    private String telefono;
    private String programa;
    private String estado;

    public Estudiante() {
    }

    public Estudiante(int estudianteId, String documentoId, String nombreCompleto, String correo, String telefono, String programa, String estado) {
        this.estudianteId = estudianteId;
        this.documentoId = documentoId;
        this.nombreCompleto = nombreCompleto;
        this.correo = correo;
        this.telefono = telefono;
        this.programa = programa;
        this.estado = estado;
    }

    // Getters
    public int getEstudianteId() {
        return estudianteId;
    }

    public String getDocumentoId() {
        return documentoId;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getPrograma() {
        return programa;
    }

    public String getEstado() {
        return estado;
    }

    // Setters
    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public void setDocumentoId(String documentoId) {
        this.documentoId = documentoId;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}