import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CamaDAO {

    private static final String SELECT_ALL = "SELECT * FROM cama";
    private static final String INSERT_SQL =
            "INSERT INTO cama (etiqueta, estado, habitacion_id) VALUES (?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM cama WHERE cama_id = ?";
    private static final String DELETE_SQL = "DELETE FROM cama WHERE cama_id = ?";



    public List<Cama> seleccionarTodos() {
        List<Cama> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Cama entidad = new Cama();
                entidad.setCamaId(resultSet.getInt("cama_id"));
                entidad.setEtiqueta(resultSet.getString("etiqueta"));
                entidad.setEstado(resultSet.getString("estado"));
                entidad.setHabitacionId(resultSet.getInt("habitacion_id"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer camas: " + e.getMessage());
        }
        return entidades;
    }


    public boolean insertarCama(Cama cama) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, cama.getEtiqueta());
            preparedStatement.setString(2, cama.getEstado());
            preparedStatement.setInt(3, cama.getHabitacionId());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar cama: " + e.getMessage());
            return false;
        }
    }

    public Cama seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Cama entidad = new Cama();
                    entidad.setCamaId(resultSet.getInt("cama_id"));
                    entidad.setEtiqueta(resultSet.getString("etiqueta"));
                    entidad.setEstado(resultSet.getString("estado"));
                    entidad.setHabitacionId(resultSet.getInt("habitacion_id"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar cama por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarCama(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar cama (puede tener contratos asociados): " + e.getMessage());
            return false;
        }
    }
}