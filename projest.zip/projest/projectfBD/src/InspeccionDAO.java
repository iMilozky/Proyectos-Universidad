
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InspeccionDAO {

    // --- CONSTANTES SQL ---
    private static final String SELECT_ALL = "SELECT * FROM inspeccion";
    private static final String INSERT_SQL =
            "INSERT INTO inspeccion (fecha_inspeccion, puntaje, observaciones, id_habitacion) VALUES (?, ?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM inspeccion WHERE inspeccion_id = ?";
    private static final String DELETE_SQL = "DELETE FROM inspeccion WHERE id_inspeccion = ?";

    // --- METODO READ: LISTAR TODOS ---
    public List<Inspeccion> seleccionarTodos() {
        List<Inspeccion> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Inspeccion entidad = new Inspeccion();
                entidad.setIdInspeccion(resultSet.getInt("id_inspeccion"));
                entidad.setFechaInspeccion(resultSet.getDate("fecha_inspeccion"));
                entidad.setPuntaje(resultSet.getDouble("puntaje"));
                entidad.setObservaciones(resultSet.getString("observaciones"));
                entidad.setIdHabitacion(resultSet.getInt("id_habitacion"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer inspecciones: " + e.getMessage());
        }
        return entidades;
    }

    // --- NUEVO METODO CREATE: INSERTAR ---
    public boolean insertarInspeccion(Inspeccion inspeccion) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setDate(1, inspeccion.getFechaInspeccion());
            preparedStatement.setDouble(2, inspeccion.getPuntaje());
            preparedStatement.setString(3, inspeccion.getObservaciones());
            preparedStatement.setInt(4, inspeccion.getIdHabitacion()); // Clave Foranea

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar inspeccion: " + e.getMessage());
            return false;
        }
    }

    // Metodo auxiliar de busqueda por ID
    public Inspeccion seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Inspeccion entidad = new Inspeccion();
                    entidad.setIdInspeccion(resultSet.getInt("inspeccion_id"));
                    entidad.setFechaInspeccion(resultSet.getDate("fecha_inspeccion"));
                    entidad.setPuntaje(resultSet.getDouble("puntaje"));
                    entidad.setObservaciones(resultSet.getString("observaciones"));
                    entidad.setIdHabitacion(resultSet.getInt("habitacion_id"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar inspeccion por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarInspeccion(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar inspeccion: " + e.getMessage());
            return false;
        }
    }
}