import java.math.BigDecimal;
import java.sql.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuApp {

    private static EstudianteDAO estudianteDAO = new EstudianteDAO();
    private static HabitacionDAO habitacionDAO = new HabitacionDAO();
    private static ContratoDAO contratoDAO = new ContratoDAO();
    private static CamaDAO camaDAO = new CamaDAO();
    private static PagoDAO pagoDAO = new PagoDAO();
    private static ResidenciaDAO residenciaDAO = new ResidenciaDAO();
    private static ServicioDAO servicioDAO = new ServicioDAO();
    private static InspeccionDAO inspeccionDAO = new InspeccionDAO();
    private static ServicioHabitacionDAO servicioHabitacionDAO = new ServicioHabitacionDAO();

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = 0;

        do {
            mostrarMenuPrincipal();
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine();

                if (opcion >= 1 && opcion <= 9) {
                    menuEntidad(opcion);
                } else if (opcion == 0) {
                    System.out.println("Saliendo de la aplicacion. Gracias por usar la gestion de viviendas.");
                } else {
                    System.out.println("Opcion no valida. Introduce un numero del 0 al 8.");
                }
            } else {
                System.out.println("Entrada no valida. Introduce un numero.");
                scanner.nextLine();
                opcion = -1;
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("\n===== GESTION DE VIVIENDAS UNIVERSITARIAS =====");
        System.out.println("1. Entidad Estudiante");
        System.out.println("2. Entidad Habitacion");
        System.out.println("3. Entidad Contrato");
        System.out.println("4. Entidad Cama");
        System.out.println("5. Entidad Pago");
        System.out.println("6. Entidad Residencia");
        System.out.println("7. Entidad Servicio");
        System.out.println("8. Entidad Inspeccion");
        System.out.println("9. Entidad Servicio Habitacion");
        System.out.println("0. Salir");
        System.out.print("Selecciona una entidad para gestionar: ");
    }

    private static void menuEntidad(int opcionEntidad) {

        String nombreEntidad = obtenerNombreEntidad(opcionEntidad);
        int opcionCRUD;

        do {
            System.out.printf("\n--- GESTION DE %s ---\n", nombreEntidad.toUpperCase());
            System.out.println("1. Insertar (CREATE)");
            System.out.println("2. Listar Todos (READ)");
            System.out.println("3. Actualizar (UPDATE) - No implementado aun");
            System.out.println("4. Eliminar (DELETE)"); // HABILITADO
            System.out.println("0. Volver al Menu Principal");
            System.out.print("Selecciona una accion: ");

            if (scanner.hasNextInt()) {
                opcionCRUD = scanner.nextInt();
                scanner.nextLine();

                if (opcionCRUD == 1) { // Logica de INSERT
                    ejecutarInsertar(opcionEntidad);
                } else if (opcionCRUD == 2) { // Logica de READ
                    ejecutarListar(opcionEntidad);
                } else if (opcionCRUD == 4) { // Logica de DELETE **NUEVO**
                    ejecutarEliminar(opcionEntidad);
                } else if (opcionCRUD == 0) {
                    return;
                } else {
                    System.out.println("Funcionalidad no implementada aun.");
                }
            } else {
                System.out.println("Entrada no valida.");
                scanner.nextLine();
                opcionCRUD = -1;
            }
        } while (opcionCRUD != 0);
    }

    private static String obtenerNombreEntidad(int opcion) {
        return switch (opcion) {
            case 1 -> "Estudiante";
            case 2 -> "Habitacion";
            case 3 -> "Contrato";
            case 4 -> "Cama";
            case 5 -> "Pago";
            case 6 -> "Residencia";
            case 7 -> "Servicio";
            case 8 -> "Inspeccion";
            case 9 -> "ServicioHabitacion";
            default -> "Desconocida";
        };
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                int valor = scanner.nextInt();
                scanner.nextLine();
                return valor;
            } catch (InputMismatchException e) {
                System.out.println("Entrada no valida. Debe ser un numero entero.");
                scanner.nextLine();
            }
        }
    }

    private static double leerDoble(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                double valor = scanner.nextDouble();
                scanner.nextLine();
                return valor;
            } catch (InputMismatchException e) {
                System.out.println("Entrada no valida. Debe ser un numero decimal (ej: 4.5).");
                scanner.nextLine();
            }
        }
    }


    private static void ejecutarEliminar(int opcion) {
        String entidad = obtenerNombreEntidad(opcion);
        System.out.printf("\n--- ELIMINANDO %s ---\n", entidad.toUpperCase());

        if (opcion == 9) {
            eliminarServicioHabitacion();
            return;
        }

        int idAEliminar = leerEntero("Introduce el ID del registro de " + entidad + " a ELIMINAR: ");

        boolean exito = false;
        switch (opcion) {
            case 1: exito = estudianteDAO.eliminarEstudiante(idAEliminar); break;
            case 2: exito = habitacionDAO.eliminarHabitacion(idAEliminar); break;
            case 3: exito = contratoDAO.eliminarContrato(idAEliminar); break;
            case 4: exito = camaDAO.eliminarCama(idAEliminar); break;
            case 5: exito = pagoDAO.eliminarPago(idAEliminar); break;
            case 6: exito = residenciaDAO.eliminarResidencia(idAEliminar); break;
            case 7: exito = servicioDAO.eliminarServicio(idAEliminar); break;
            case 8: exito = inspeccionDAO.eliminarInspeccion(idAEliminar); break;
            default: System.out.println("Entidad no reconocida."); return;
        }

        if (exito) {
            System.out.printf("%s con ID %d eliminado correctamente.\n", entidad, idAEliminar);
        } else {
            System.out.printf("Fallo la eliminacion de %s con ID %d. Revisa la consola para ver si hay errores de claves foraneas.\n", entidad, idAEliminar);
        }
    }

    private static void eliminarServicioHabitacion() {
        System.out.println("\n--- ELIMINACION DE SERVICIO_HABITACION ---");
        System.out.println("Necesitas el ID de la Habitacion y el ID del Servicio para eliminar la relacion.");

        int habitacionId = leerEntero("Introduce el ID de la Habitacion: ");
        int servicioId = leerEntero("Introduce el ID del Servicio: ");

        if (servicioHabitacionDAO.eliminarServicioHabitacion(habitacionId, servicioId)) {
            System.out.printf("Relacion ServicioHabitacion (Habitacion ID: %d, Servicio ID: %d) eliminada correctamente.\n", habitacionId, servicioId);
        } else {
            System.out.println("Fallo la eliminacion de ServicioHabitacion. Revisa si la relacion existe.");
        }
    }


    // --- METODOS CREATE: EJECUTAR INSERTAR (Para centralizar el menu) ---

    private static void ejecutarInsertar(int opcionEntidad) {
        if (opcionEntidad == 1) {
            insertarNuevoEstudiante();
        } else if (opcionEntidad == 2) {
            insertarNuevaHabitacion();
        } else if (opcionEntidad == 3) {
            insertarNuevoContrato();
        } else if (opcionEntidad == 4) {
            insertarNuevaCama();
        } else if (opcionEntidad == 5) {
            insertarNuevoPago();
        } else if (opcionEntidad == 6) {
            insertarNuevaResidencia();
        } else if (opcionEntidad == 7) {
            insertarNuevoServicio();
        } else if (opcionEntidad == 8) {
            insertarNuevaInspeccion();
        } else if (opcionEntidad == 9) {
            insertarServicioHabitacion();
        }
    }


    private static void insertarNuevaResidencia() {
        System.out.println("\n--- INSERCION DE NUEVA RESIDENCIA ---");
        Residencia nuevaResidencia = new Residencia();

        System.out.print("Nombre de la Residencia: ");
        nuevaResidencia.setNombre(scanner.nextLine());

        System.out.print("Direccion: ");
        nuevaResidencia.setDireccion(scanner.nextLine());

        if (residenciaDAO.insertarResidencia(nuevaResidencia)) {
            System.out.println("Residencia insertada correctamente");
        } else {
            System.out.println("Fallo la insercion de la residencia.");
        }
    }

    private static void insertarNuevoEstudiante() {
        System.out.println("\n--- INSERCION DE NUEVO ESTUDIANTE ---");
        Estudiante nuevoEstudiante = new Estudiante();

        System.out.print("Documento ID: ");
        nuevoEstudiante.setDocumentoId(scanner.nextLine());

        System.out.print("Nombre Completo: ");
        nuevoEstudiante.setNombreCompleto(scanner.nextLine());

        System.out.print("Correo: ");
        nuevoEstudiante.setCorreo(scanner.nextLine());

        System.out.print("Telefono: ");
        nuevoEstudiante.setTelefono(scanner.nextLine());

        System.out.print("Programa: ");
        nuevoEstudiante.setPrograma(scanner.nextLine());

        nuevoEstudiante.setEstado("Activo");

        if (estudianteDAO.insertarEstudiante(nuevoEstudiante)) {
            System.out.println("Estudiante insertado correctamente");
        } else {
            System.out.println("Fallo la insercion del estudiante.");
        }
    }

    private static void insertarNuevaHabitacion() {
        System.out.println("\n--- INSERCION DE NUEVA HABITACION ---");
        Habitacion nuevaHabitacion = new Habitacion();

        System.out.println("\nResidencias disponibles:");
        residenciaDAO.seleccionarTodos().forEach(r ->
                System.out.printf("   [ID: %d] %s en %s\n", r.getResidenciaId(), r.getNombre(), r.getDireccion()));
        System.out.println("------------------------------------");

        int residenciaId = -1;
        while (residenciaId == -1) {
            System.out.print("Introduce el ID de la Residencia (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (residenciaDAO.seleccionarPorId(idIngresado) != null) {
                    residenciaId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Residencia no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevaHabitacion.setResidenciaId(residenciaId);

        System.out.print("Codigo de la Habitacion (Ej: R3-303): ");
        nuevaHabitacion.setCodigo(scanner.nextLine());

        System.out.print("Tipo (Doble/Individual): ");
        nuevaHabitacion.setTipo(scanner.nextLine());

        nuevaHabitacion.setEstado("Disponible");

        if (habitacionDAO.insertarHabitacion(nuevaHabitacion)) {
            System.out.println("Habitacion insertada correctamente");
        } else {
            System.out.println("Fallo la insercion de la habitacion.");
        }
    }

    private static void insertarNuevaCama() {
        System.out.println("\n--- INSERCION DE NUEVA CAMA ---");
        Cama nuevaCama = new Cama();

        System.out.println("\nHabitaciones disponibles:");
        habitacionDAO.seleccionarTodos().forEach(h ->
                System.out.printf("   [ID: %d] Codigo: %s | Tipo: %s | Estado: %s\n", h.getHabitacionId(), h.getCodigo(), h.getTipo(), h.getEstado()));
        System.out.println("------------------------------------");

        int habitacionId = -1;
        while (habitacionId == -1) {
            System.out.print("Introduce el ID de la Habitacion (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (habitacionDAO.seleccionarPorId(idIngresado) != null) {
                    habitacionId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Habitacion no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevaCama.setHabitacionId(habitacionId);

        System.out.print("Etiqueta de la Cama (Ej: Cama-A): ");
        nuevaCama.setEtiqueta(scanner.nextLine());

        nuevaCama.setEstado("Disponible");

        if (camaDAO.insertarCama(nuevaCama)) {
            System.out.println("Cama insertada correctamente");
        } else {
            System.out.println("Fallo la insercion de la cama.");
        }
    }

    private static void insertarNuevoServicio() {
        System.out.println("\n--- INSERCION DE NUEVO SERVICIO ---");
        Servicio nuevoServicio = new Servicio();

        System.out.print("Nombre del Servicio (Ej: Internet Fibra): ");
        nuevoServicio.setNombre(scanner.nextLine());

        System.out.print("Descripcion: ");
        nuevoServicio.setDescripcion(scanner.nextLine());

        System.out.print("Tipo de Tarifa (Fija/Variable): ");
        nuevoServicio.setTipoTarifa(scanner.nextLine());

        if (servicioDAO.insertarServicio(nuevoServicio)) {
            System.out.println("Servicio insertado correctamente");
        } else {
            System.out.println("Fallo la insercion del servicio.");
        }
    }

    private static void insertarNuevoContrato() {
        System.out.println("\n--- INSERCION DE NUEVO CONTRATO ---");
        Contrato nuevoContrato = new Contrato();

        // 1. Validar Clave Foranea: Estudiante ID
        System.out.println("\nEstudiantes disponibles:");
        estudianteDAO.seleccionarTodos().forEach(e ->
                System.out.printf("   [ID: %d] %s (Doc: %s)\n", e.getEstudianteId(), e.getNombreCompleto(), e.getDocumentoId()));
        System.out.println("------------------------------------");

        int estudianteId = -1;
        while (estudianteId == -1) {
            System.out.print("Introduce el ID del Estudiante (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (estudianteDAO.seleccionarPorId(idIngresado) != null) {
                    estudianteId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Estudiante no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevoContrato.setEstudianteId(estudianteId);

        // 2. Validar Clave Foranea: Cama ID
        System.out.println("\nCamas disponibles:");
        camaDAO.seleccionarTodos().forEach(c ->
                System.out.printf("   [ID: %d] Etiqueta: %s | Estado: %s | Habitacion ID: %d\n", c.getCamaId(), c.getEtiqueta(), c.getEstado(), c.getHabitacionId()));
        System.out.println("------------------------------------");

        int camaId = -1;
        while (camaId == -1) {
            System.out.print("Introduce el ID de la Cama (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (camaDAO.seleccionarPorId(idIngresado) != null) {
                    camaId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Cama no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevoContrato.setCamaId(camaId);


        // Fecha de Inicio
        System.out.print("Fecha de Inicio (YYYY-MM-DD): ");
        String fechaInicioStr = scanner.nextLine();
        nuevoContrato.setFechaInicio(Date.valueOf(fechaInicioStr));

        // Fecha de Fin
        System.out.print("Fecha de Fin (YYYY-MM-DD): ");
        String fechaFinStr = scanner.nextLine();
        nuevoContrato.setFechaFin(Date.valueOf(fechaFinStr));

        // Pago Mensualidad
        double pagoMensualidadDouble = -1;
        while (pagoMensualidadDouble == -1) {
            System.out.print("Pago de Mensualidad: ");
            if (scanner.hasNextDouble()) {
                pagoMensualidadDouble = scanner.nextDouble();
                scanner.nextLine();
            } else {
                System.out.println("Entrada no valida. Debe ser un numero decimal.");
                scanner.nextLine();
            }
        }

        nuevoContrato.setPagoMensualidad(BigDecimal.valueOf(pagoMensualidadDouble));

        // Deposito
        double depositoDouble = -1;
        while (depositoDouble == -1) {
            System.out.print("Monto de Deposito: ");
            if (scanner.hasNextDouble()) {
                depositoDouble = scanner.nextDouble();
                scanner.nextLine();
            } else {
                System.out.println("Entrada no valida. Debe ser un numero decimal.");
                scanner.nextLine();
            }
        }
        nuevoContrato.setDeposito(BigDecimal.valueOf(depositoDouble));

        nuevoContrato.setEstado("Vigente");

        if (contratoDAO.insertarContrato(nuevoContrato)) {
            System.out.println("Contrato insertado correctamente");
        } else {
            System.out.println("Fallo la insercion del contrato.");
        }
    }

    private static void insertarNuevoPago() {
        System.out.println("\n--- INSERCION DE NUEVO PAGO ---");
        Pago nuevoPago = new Pago();

        //Validar Clave Foranea: Contrato ID
        System.out.println("\nContratos disponibles:");
        contratoDAO.seleccionarTodos().forEach(c ->
                System.out.printf("   [ID: %d] Estudiante ID: %d | Inicio: %s | Pago: %s\n", c.getContratoId(), c.getEstudianteId(), c.getFechaInicio(), c.getPagoMensualidad()));
        System.out.println("------------------------------------");

        int contratoId = -1;
        while (contratoId == -1) {
            System.out.print("Introduce el ID del Contrato (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (contratoDAO.seleccionarPorId(idIngresado) != null) {
                    contratoId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Contrato no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevoPago.setContratoId(contratoId);


        System.out.print("Metodo de Pago (Efectivo/Transferencia/Tarjeta): ");
        nuevoPago.setMetodoPago(scanner.nextLine());

        System.out.print("Fecha de Pago (YYYY-MM-DD): ");
        String fechaPagoStr = scanner.nextLine();
        nuevoPago.setFechaPago(Date.valueOf(fechaPagoStr));


        // Monto
        double montoDouble = -1;
        while (montoDouble == -1) {
            System.out.print("Monto a pagar: ");
            if (scanner.hasNextDouble()) {
                montoDouble = scanner.nextDouble();
                scanner.nextLine();
            } else {
                System.out.println("Entrada no valida. Debe ser un numero decimal.");
                scanner.nextLine();
            }
        }
        nuevoPago.setMonto(BigDecimal.valueOf(montoDouble));

        if (pagoDAO.insertarPago(nuevoPago)) {
            System.out.println("Pago insertado correctamente");
        } else {
            System.out.println("Fallo la insercion del pago.");
        }
    }

    private static void insertarNuevaInspeccion() {
        System.out.println("\n--- INSERCION DE NUEVA INSPECCION ---");
        Inspeccion nuevaInspeccion = new Inspeccion();

        // Validar Clave Foranea: Habitacion ID
        System.out.println("\nHabitaciones disponibles:");
        habitacionDAO.seleccionarTodos().forEach(h ->
                System.out.printf("   [ID: %d] Codigo: %s | Tipo: %s | Estado: %s\n", h.getHabitacionId(), h.getCodigo(), h.getTipo(), h.getEstado()));
        System.out.println("------------------------------------");

        int habitacionId = -1;
        while (habitacionId == -1) {
            System.out.print("Introduce el ID de la Habitacion (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (habitacionDAO.seleccionarPorId(idIngresado) != null) {
                    habitacionId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Habitacion no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevaInspeccion.setIdHabitacion(habitacionId);

        System.out.print("Fecha de Inspeccion (YYYY-MM-DD): ");
        String fechaInspeccionStr = scanner.nextLine();
        nuevaInspeccion.setFechaInspeccion(Date.valueOf(fechaInspeccionStr));

        double puntajeDouble = -1;
        while (puntajeDouble == -1) {
            System.out.print("Puntaje de la Inspeccion (0.0 a 5.0): ");
            if (scanner.hasNextDouble()) {
                puntajeDouble = scanner.nextDouble();
                scanner.nextLine();
            } else {
                System.out.println("Entrada no valida. Debe ser un numero decimal.");
                scanner.nextLine();
            }
        }
        nuevaInspeccion.setPuntaje(puntajeDouble);

        System.out.print("Observaciones: ");
        nuevaInspeccion.setObservaciones(scanner.nextLine());

        if (inspeccionDAO.insertarInspeccion(nuevaInspeccion)) {
            System.out.println("Inspeccion insertada correctamente");
        } else {
            System.out.println("Fallo la insercion de la inspeccion.");
        }
    }

    private static void insertarServicioHabitacion() {
        System.out.println("\n--- INSERCION DE SERVICIO A HABITACION ---");
        ServicioHabitacion nuevaUnion = new ServicioHabitacion();

        //Validar Clave Foranea: Habitacion ID
        System.out.println("\nHabitaciones disponibles:");
        habitacionDAO.seleccionarTodos().forEach(h ->
                System.out.printf("   [ID: %d] Codigo: %s | Tipo: %s\n", h.getHabitacionId(), h.getCodigo(), h.getTipo()));
        System.out.println("------------------------------------");

        int habitacionId = -1;
        while (habitacionId == -1) {
            System.out.print("Introduce el ID de la Habitacion (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (habitacionDAO.seleccionarPorId(idIngresado) != null) {
                    habitacionId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Habitacion no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevaUnion.setHabitacionId(habitacionId);

        // Validar Clave Foranea: Servicio ID
        System.out.println("\nServicios disponibles:");
        servicioDAO.seleccionarTodos().forEach(s ->
                System.out.printf("   [ID: %d] Nombre: %s | Tarifa: %s\n", s.getIdServicio(), s.getNombre(), s.getTipoTarifa()));
        System.out.println("------------------------------------");

        int servicioId = -1;
        while (servicioId == -1) {
            System.out.print("Introduce el ID del Servicio (de la lista anterior): ");
            if (scanner.hasNextInt()) {
                int idIngresado = scanner.nextInt();
                scanner.nextLine();
                if (servicioDAO.seleccionarPorId(idIngresado) != null) {
                    servicioId = idIngresado;
                } else {
                    System.out.println("Error: El ID de Servicio no existe. Intenta de nuevo.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ser un numero.");
                scanner.nextLine();
            }
        }
        nuevaUnion.setServicioId(servicioId);

        // Fecha de Inicio
        System.out.print("Fecha de Inicio del servicio (YYYY-MM-DD): ");
        String fechaInicioStr = scanner.nextLine();
        nuevaUnion.setFechaInicio(Date.valueOf(fechaInicioStr));

        // Fecha de Fin
        System.out.print("Fecha de Fin del servicio (YYYY-MM-DD): ");
        String fechaFinStr = scanner.nextLine();
        nuevaUnion.setFechaFin(Date.valueOf(fechaFinStr));

        // Costo Mensual - Usamos la función auxiliar leerDoble
        double costoMensualDouble = leerDoble("Costo Mensual del Servicio: ");
        nuevaUnion.setCostoMensual(BigDecimal.valueOf(costoMensualDouble));

        // 3. Ejecutar insercion
        if (servicioHabitacionDAO.insertarServicioHabitacion(nuevaUnion)) {
            System.out.println("ServicioHabitacion insertado correctamente");
        } else {
            System.out.println("Fallo la insercion de ServicioHabitacion. Revisa si la combinacion ya existe.");
        }
    }


    private static void ejecutarListar(int opcion) {
        String entidad = obtenerNombreEntidad(opcion);
        System.out.printf("\n--- LISTANDO %s ---\n", entidad.toUpperCase());

        switch (opcion) {
            case 1:
                estudianteDAO.seleccionarTodos().forEach(e ->
                        System.out.printf("ID: %d | Nombre: %s | Documento: %s | Programa: %s\n", e.getEstudianteId(), e.getNombreCompleto(), e.getDocumentoId(), e.getPrograma()));
                break;
            case 2:
                habitacionDAO.seleccionarTodos().forEach(h ->
                        System.out.printf("ID: %d | Codigo: %s | Tipo: %s | Estado: %s | Residencia ID: %d\n", h.getHabitacionId(), h.getCodigo(), h.getTipo(), h.getEstado(), h.getResidenciaId()));
                break;
            case 3:
                contratoDAO.seleccionarTodos().forEach(c ->
                        System.out.printf("ID: %d | Inicio: %s | Pago: %s | Estudiante ID: %d | Cama ID: %d\n", c.getContratoId(), c.getFechaInicio(), c.getPagoMensualidad(), c.getEstudianteId(), c.getCamaId()));
                break;
            case 4:
                camaDAO.seleccionarTodos().forEach(c ->
                        System.out.printf("ID: %d | Etiqueta: %s | Estado: %s | Habitacion ID: %d\n", c.getCamaId(), c.getEtiqueta(), c.getEstado(), c.getHabitacionId()));
                break;
            case 5:
                pagoDAO.seleccionarTodos().forEach(p ->
                        System.out.printf("ID: %d | Monto: %s | Fecha: %s | Metodo: %s | Contrato ID: %d\n", p.getPagoId(), p.getMonto(), p.getFechaPago(), p.getMetodoPago(), p.getContratoId()));
                break;
            case 6:
                residenciaDAO.seleccionarTodos().forEach(r ->
                        System.out.printf("ID: %d | Nombre: %s | Direccion: %s\n", r.getResidenciaId(), r.getNombre(), r.getDireccion()));
                break;
            case 7:
                servicioDAO.seleccionarTodos().forEach(s ->
                        System.out.printf("ID: %d | Nombre: %s | Tarifa: %s\n", s.getIdServicio(), s.getNombre(), s.getTipoTarifa()));
                break;
            case 8:
                inspeccionDAO.seleccionarTodos().forEach(i ->
                        System.out.printf("ID: %d | Habitacion ID: %d | Puntaje: %.2f | Fecha: %s\n", i.getIdInspeccion(), i.getIdHabitacion(), i.getPuntaje(), i.getFechaInspeccion()));
                break;
            case 9:
                servicioHabitacionDAO.seleccionarTodos().forEach(sh ->
                        System.out.printf("Habitacion ID: %d | Servicio ID: %d | Inicio: %s | Fin: %s | Costo Mensual: %s\n",
                                sh.getHabitacionId(),
                                sh.getServicioId(),
                                sh.getFechaInicio(),
                                sh.getFechaFin(),
                                sh.getCostoMensual()));
                break;
            default:
                System.out.println("No se puede listar esta entidad.");
        }
    }
}