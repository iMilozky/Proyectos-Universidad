import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PagoDAO {

    private static final String SELECT_ALL = "SELECT * FROM pago";
    private static final String INSERT_SQL =
            "INSERT INTO pago (metodo_pago, fecha_pago, monto, contrato_id) VALUES (?, ?, ?, ?)";
    private static final String DELETE_SQL = "DELETE FROM pago WHERE pago_id = ?";

    // --- METODO READ: LISTAR TODOS ---
    public List<Pago> seleccionarTodos() {
        List<Pago> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Pago entidad = new Pago();
                entidad.setPagoId(resultSet.getInt("pago_id"));
                entidad.setMetodoPago(resultSet.getString("metodo_pago"));
                entidad.setFechaPago(resultSet.getDate("fecha_pago"));
                entidad.setMonto(resultSet.getBigDecimal("monto"));
                entidad.setContratoId(resultSet.getInt("contrato_id"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer pagos: " + e.getMessage());
        }
        return entidades;
    }

    // --- NUEVO METODO CREATE: INSERTAR ---
    public boolean insertarPago(Pago pago) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, pago.getMetodoPago());
            preparedStatement.setDate(2, pago.getFechaPago());
            preparedStatement.setBigDecimal(3, pago.getMonto());
            preparedStatement.setInt(4, pago.getContratoId());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarPago(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar pago: " + e.getMessage());
            return false;
        }
    }
}