import java.math.BigDecimal;
import java.sql.Date;

public class ServicioHabitacion {

    private int habitacionId;
    private int servicioId;
    private Date fechaInicio;
    private Date fechaFin;
    private BigDecimal costoMensual;

    public ServicioHabitacion() {
    }

    public int getHabitacionId() {
        return habitacionId;
    }
    public void setHabitacionId(int habitacionId) {
        this.habitacionId = habitacionId;
    }

    public int getServicioId() {
        return servicioId;
    }
    public void setServicioId(int servicioId) {
        this.servicioId = servicioId;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }
    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public BigDecimal getCostoMensual() {
        return costoMensual;
    }
    public void setCostoMensual(BigDecimal costoMensual) {
        this.costoMensual = costoMensual;
    }
}