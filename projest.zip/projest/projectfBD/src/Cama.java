public class Cama {

    private int camaId;
    private String etiqueta;
    private String estado;
    private int habitacionId;

    public Cama() {
    }

    public Cama(int camaId, String etiqueta, String estado, int habitacionId) {
        this.camaId = camaId;
        this.etiqueta = etiqueta;
        this.estado = estado;
        this.habitacionId = habitacionId;
    }

    // Getters
    public int getCamaId() {
        return camaId;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public String getEstado() {
        return estado;
    }

    public int getHabitacionId() {
        return habitacionId;
    }

    // Setters
    public void setCamaId(int camaId) {
        this.camaId = camaId;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setHabitacionId(int habitacionId) {
        this.habitacionId = habitacionId;
    }
}