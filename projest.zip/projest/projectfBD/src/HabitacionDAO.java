import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HabitacionDAO {

    private static final String SELECT_ALL = "SELECT * FROM habitacion";

    private static final String INSERT_SQL =
            "INSERT INTO habitacion (codigo, estado, tipo, residencia_id) VALUES (?, ?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM habitacion WHERE habitacion_id = ?";
    private static final String DELETE_SQL = "DELETE FROM habitacion WHERE habitacion_id = ?";


    public List<Habitacion> seleccionarTodos() {
        List<Habitacion> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Habitacion entidad = new Habitacion();
                entidad.setHabitacionId(resultSet.getInt("habitacion_id"));
                entidad.setCodigo(resultSet.getString("codigo"));
                entidad.setEstado(resultSet.getString("estado"));
                entidad.setTipo(resultSet.getString("tipo"));
                entidad.setResidenciaId(resultSet.getInt("residencia_id"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer habitaciones: " + e.getMessage());
        }
        return entidades;
    }

    public boolean insertarHabitacion(Habitacion habitacion) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, habitacion.getCodigo());
            preparedStatement.setString(2, habitacion.getEstado());
            preparedStatement.setString(3, habitacion.getTipo());
            preparedStatement.setInt(4, habitacion.getResidenciaId()); // Clave Foránea

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar habitación: " + e.getMessage());
            return false;
        }
    }

    public Habitacion seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Habitacion entidad = new Habitacion();
                    entidad.setHabitacionId(resultSet.getInt("habitacion_id"));
                    entidad.setCodigo(resultSet.getString("codigo"));
                    entidad.setEstado(resultSet.getString("estado"));
                    entidad.setTipo(resultSet.getString("tipo"));
                    entidad.setResidenciaId(resultSet.getInt("residencia_id"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar habitación por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarHabitacion(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar habitacion (puede tener camas/inspecciones/servicios asociados): " + e.getMessage());
            return false;
        }
    }
}