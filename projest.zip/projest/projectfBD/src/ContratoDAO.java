import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContratoDAO {

    private static final String SELECT_ALL = "SELECT * FROM contrato";
    private static final String INSERT_SQL =
            "INSERT INTO contrato (fecha_inicio, fecha_fin, pago_mensualidad, deposito, estado, cama_id, estudiante_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM contrato WHERE contrato_id = ?";
    private static final String DELETE_SQL = "DELETE FROM contrato WHERE contrato_id = ?";

    // --- METODO READ: LISTAR TODOS ---
    public List<Contrato> seleccionarTodos() {
        List<Contrato> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Contrato entidad = new Contrato();
                entidad.setContratoId(resultSet.getInt("contrato_id"));
                entidad.setFechaInicio(resultSet.getDate("fecha_inicio"));
                entidad.setFechaFin(resultSet.getDate("fecha_fin"));
                entidad.setPagoMensualidad(resultSet.getBigDecimal("pago_mensualidad")); // CORREGIDO
                entidad.setDeposito(resultSet.getBigDecimal("deposito"));                // CORREGIDO
                entidad.setEstado(resultSet.getString("estado"));
                entidad.setCamaId(resultSet.getInt("cama_id"));
                entidad.setEstudianteId(resultSet.getInt("estudiante_id"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer contratos: " + e.getMessage());
        }
        return entidades;
    }

    // --- METODO CREATE: INSERTAR ---
    public boolean insertarContrato(Contrato contrato) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setDate(1, contrato.getFechaInicio());
            preparedStatement.setDate(2, contrato.getFechaFin());
            preparedStatement.setBigDecimal(3, contrato.getPagoMensualidad());
            preparedStatement.setBigDecimal(4, contrato.getDeposito());
            preparedStatement.setString(5, contrato.getEstado());
            preparedStatement.setInt(6, contrato.getCamaId());
            preparedStatement.setInt(7, contrato.getEstudianteId());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar contrato: " + e.getMessage());
            return false;
        }
    }

    public Contrato seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Contrato entidad = new Contrato();
                    entidad.setContratoId(resultSet.getInt("contrato_id"));
                    entidad.setFechaInicio(resultSet.getDate("fecha_inicio"));
                    entidad.setFechaFin(resultSet.getDate("fecha_fin"));
                    entidad.setPagoMensualidad(resultSet.getBigDecimal("pago_mensualidad"));
                    entidad.setDeposito(resultSet.getBigDecimal("deposito"));
                    entidad.setEstado(resultSet.getString("estado"));
                    entidad.setCamaId(resultSet.getInt("cama_id"));
                    entidad.setEstudianteId(resultSet.getInt("estudiante_id"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar contrato por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarContrato(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar contrato (puede tener pagos asociados): " + e.getMessage());
            return false;
        }
    }
}