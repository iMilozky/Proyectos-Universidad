import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResidenciaDAO {

    private static final String SELECT_ALL = "SELECT * FROM residencia";
    private static final String INSERT_SQL =
            "INSERT INTO residencia (nombre, direccion) VALUES (?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM residencia WHERE residencia_id = ?";
    private static final String DELETE_SQL = "DELETE FROM residencia WHERE residencia_id = ?";

    public List<Residencia> seleccionarTodos() {
        List<Residencia> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Residencia entidad = new Residencia();
                entidad.setResidenciaId(resultSet.getInt("residencia_id"));
                entidad.setNombre(resultSet.getString("nombre"));
                entidad.setDireccion(resultSet.getString("direccion"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer residencias: " + e.getMessage());
        }
        return entidades;
    }
    public boolean insertarResidencia(Residencia residencia) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, residencia.getNombre());
            preparedStatement.setString(2, residencia.getDireccion());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar residencia: " + e.getMessage());
            return false;
        }
    }

    public Residencia seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Residencia entidad = new Residencia();
                    entidad.setResidenciaId(resultSet.getInt("residencia_id"));
                    entidad.setNombre(resultSet.getString("nombre"));
                    entidad.setDireccion(resultSet.getString("direccion"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar residencia por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarResidencia(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar residencia (puede tener habitaciones asociadas): " + e.getMessage());
            return false;
        }
    }
}