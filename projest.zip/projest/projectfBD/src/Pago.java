import java.math.BigDecimal;
import java.sql.Date;

public class Pago {

    private int pagoId;
    private String metodoPago;
    private Date fechaPago;
    private BigDecimal monto;
    private int contratoId;

    public Pago() {
    }

    public Pago(int pagoId, String metodoPago, Date fechaPago, BigDecimal monto, int contratoId) {
        this.pagoId = pagoId;
        this.metodoPago = metodoPago;
        this.fechaPago = fechaPago;
        this.monto = monto;
        this.contratoId = contratoId;
    }

    // Getters
    public int getPagoId() {
        return pagoId;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public Date getFechaPago() {
        return fechaPago;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public int getContratoId() {
        return contratoId;
    }

    // Setters
    public void setPagoId(int pagoId) {
        this.pagoId = pagoId;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public void setContratoId(int contratoId) {
        this.contratoId = contratoId;
    }
}