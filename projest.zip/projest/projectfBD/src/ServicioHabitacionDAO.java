import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServicioHabitacionDAO {

    private static final String SELECT_ALL = "SELECT * FROM servicio_habitacion";
    private static final String INSERT_SQL =
            "INSERT INTO servicio_habitacion (id_habitacion, id_servicio, fecha_inicio, fecha_fin, costo_mensual) VALUES (?, ?, ?, ?, ?)";
    private static final String DELETE_SQL =
            "DELETE FROM servicio_habitacion WHERE id_habitacion = ? AND id_servicio = ? ";

    // --- METODO READ: LISTAR TODOS ---
    public List<ServicioHabitacion> seleccionarTodos() {
        List<ServicioHabitacion> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                ServicioHabitacion entidad = new ServicioHabitacion();
                entidad.setHabitacionId(resultSet.getInt("id_habitacion"));
                entidad.setServicioId(resultSet.getInt("id_servicio"));
                entidad.setFechaInicio(resultSet.getDate("fecha_inicio"));
                entidad.setFechaFin(resultSet.getDate("fecha_fin"));
                entidad.setCostoMensual(resultSet.getBigDecimal("costo_mensual"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer Servicio Habitacion: " + e.getMessage());
        }
        return entidades;
    }

    // --- METODO CREATE: INSERTAR ---
    public boolean insertarServicioHabitacion(ServicioHabitacion servicioHabitacion) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setInt(1, servicioHabitacion.getHabitacionId());
            preparedStatement.setInt(2, servicioHabitacion.getServicioId());
            preparedStatement.setDate(3, servicioHabitacion.getFechaInicio());
            preparedStatement.setDate(4, servicioHabitacion.getFechaFin());
            preparedStatement.setBigDecimal(5, servicioHabitacion.getCostoMensual());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar Servicio Habitacion: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarServicioHabitacion(int habitacionId, int servicioId) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, habitacionId);
            preparedStatement.setInt(2, servicioId);

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar Servicio Habitacion: " + e.getMessage());
            return false;
        }
    }
}