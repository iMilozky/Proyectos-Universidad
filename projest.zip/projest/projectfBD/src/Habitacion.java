public class Habitacion {

    private int habitacionId;
    private String codigo;
    private String estado;
    private String tipo;
    private int residenciaId;

    public Habitacion() {
    }

    public Habitacion(int habitacionId, String codigo, String estado, String tipo, int residenciaId) {
        this.habitacionId = habitacionId;
        this.codigo = codigo;
        this.estado = estado;
        this.tipo = tipo;
        this.residenciaId = residenciaId;
    }

    // Getters
    public int getHabitacionId() {
        return habitacionId;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getEstado() {
        return estado;
    }

    public String getTipo() {
        return tipo;
    }

    public int getResidenciaId() {
        return residenciaId;
    }

    // Setters
    public void setHabitacionId(int habitacionId) {
        this.habitacionId = habitacionId;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setResidenciaId(int residenciaId) {
        this.residenciaId = residenciaId;
    }
}