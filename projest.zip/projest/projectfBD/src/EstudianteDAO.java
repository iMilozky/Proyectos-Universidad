import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {

    private static final String SELECT_ALL = "SELECT * FROM estudiante";
    private static final String INSERT_SQL =
            "INSERT INTO estudiante (documento_ID, nombre_completo, correo, telefono, programa, estado) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_BY_ID = "SELECT * FROM estudiante WHERE estudiante_id = ?";
    private static final String DELETE_SQL = "DELETE FROM estudiante WHERE estudiante_id = ?";

    public List<Estudiante> seleccionarTodos() {
        List<Estudiante> entidades = new ArrayList<>();

        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Estudiante entidad = new Estudiante();
                entidad.setEstudianteId(resultSet.getInt("estudiante_id"));
                entidad.setDocumentoId(resultSet.getString("documento_ID"));
                entidad.setNombreCompleto(resultSet.getString("nombre_completo"));
                entidad.setCorreo(resultSet.getString("correo"));
                entidad.setTelefono(resultSet.getString("telefono"));
                entidad.setPrograma(resultSet.getString("programa"));
                entidad.setEstado(resultSet.getString("estado"));
                entidades.add(entidad);
            }
        } catch (SQLException e) {
            System.err.println("Error al leer estudiantes: " + e.getMessage());
        }
        return entidades;
    }


    public boolean insertarEstudiante(Estudiante estudiante) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {

            preparedStatement.setString(1, estudiante.getDocumentoId());
            preparedStatement.setString(2, estudiante.getNombreCompleto());
            preparedStatement.setString(3, estudiante.getCorreo());
            preparedStatement.setString(4, estudiante.getTelefono());
            preparedStatement.setString(5, estudiante.getPrograma());
            preparedStatement.setString(6, estudiante.getEstado()); // Usaremos "Activo" por defecto

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            // Error común aquí: Documento ID duplicado (clave única)
            System.err.println("Error al insertar estudiante: " + e.getMessage());
            return false;
        }
    }

    public Estudiante seleccionarPorId(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID)) {

            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Estudiante entidad = new Estudiante();
                    entidad.setEstudianteId(resultSet.getInt("estudiante_id"));
                    entidad.setDocumentoId(resultSet.getString("documento_ID"));
                    entidad.setNombreCompleto(resultSet.getString("nombre_completo"));
                    entidad.setCorreo(resultSet.getString("correo"));
                    entidad.setTelefono(resultSet.getString("telefono"));
                    entidad.setPrograma(resultSet.getString("programa"));
                    entidad.setEstado(resultSet.getString("estado"));
                    return entidad;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar estudiante por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean eliminarEstudiante(int id) {
        try (Connection connection = DBconnector.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_SQL)) {

            preparedStatement.setInt(1, id);
            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar estudiante (puede tener contratos asociados): " + e.getMessage());
            return false;
        }
    }
}