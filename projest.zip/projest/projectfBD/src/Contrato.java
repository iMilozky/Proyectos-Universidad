import java.math.BigDecimal;
import java.sql.Date;

public class Contrato {

    private int contratoId;
    private Date fechaInicio;
    private Date fechaFin;
    private BigDecimal pagoMensualidad;
    private BigDecimal deposito;
    private String estado;
    private int camaId;
    private int estudianteId;

    public Contrato() {
    }

    public Contrato(int contratoId, Date fechaInicio, Date fechaFin, BigDecimal pagoMensualidad, BigDecimal deposito, String estado, int camaId, int estudianteId) {
        this.contratoId = contratoId;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.pagoMensualidad = pagoMensualidad;
        this.deposito = deposito;
        this.estado = estado;
        this.camaId = camaId;
        this.estudianteId = estudianteId;
    }

    // Getters
    public int getContratoId() {
        return contratoId;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public BigDecimal getPagoMensualidad() {
        return pagoMensualidad;
    }

    public BigDecimal getDeposito() {
        return deposito;
    }

    public String getEstado() {
        return estado;
    }

    public int getCamaId() {
        return camaId;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    // Setters
    public void setContratoId(int contratoId) {
        this.contratoId = contratoId;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public void setPagoMensualidad(BigDecimal pagoMensualidad) {
        this.pagoMensualidad = pagoMensualidad;
    }

    public void setDeposito(BigDecimal deposito) {
        this.deposito = deposito;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setCamaId(int camaId) {
        this.camaId = camaId;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }
}