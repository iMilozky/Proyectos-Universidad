import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnector {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/GestionViviandasU";
    private static final String USER = "root";
    private static final String PASS = "MFA&ip*qzMvGr3";


    public static Connection getConnection() {
        try {
            Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            return connection;
        } catch (SQLException e) {
            System.err.println("ERROR: no se pudo conectar a la base de datos.");
            System.err.println("Mensaje: " + e.getMessage());
            return null;
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("ERROR: no se pudo cerrar la conexión.");
                System.err.println("Mensaje: " + e.getMessage());
            }
        }
    }
}